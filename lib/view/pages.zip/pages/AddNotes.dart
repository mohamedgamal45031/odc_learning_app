import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:odc_workshop/viewmodel/bloc/notes_cubit.dart';
import 'package:odc_workshop/viewmodel/bloc/notes_state.dart';

class AddNotes extends StatelessWidget {
  TextEditingController titleController = new TextEditingController();
  TextEditingController desController = new TextEditingController();
  DateTime now = new DateTime.now();
  TextEditingController dateController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<NotesCubit, NotesState>(
      listener: (context, state) {},
      builder: (context, state) => Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: Icon(
            Icons.arrow_back_ios_outlined,
            color: Colors.black,
          ),
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: Center(
            child: Text(
              "Add Notes",
              style: GoogleFonts.poppins(
                  color: Colors.black,
                  fontSize: 25,
                  fontWeight: FontWeight.w600),
            ),
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(20),
                child: TextFormField(
                  controller: titleController,
                  validator: (e) {
                    if (e!.isEmpty) {
                      return "Please enter Title";
                    }
                  },
                  decoration: InputDecoration(
                    labelText: "Note Title",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(20),bottomRight:Radius.circular(20),),),
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(20),
                child: TextFormField(
                  enabled: false,

                  controller: dateController,
                  validator: (e) {},
                  decoration: InputDecoration(

                    labelText: now.toString(),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(20),bottomRight:Radius.circular(20),),),
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.all(20),
                child: TextFormField(
                  controller: desController,
                  validator: (e) {
                    if (e!.isEmpty) {
                      return "Please enter Description";
                    }
                  },
                  decoration: InputDecoration(

                    labelText: "Description",
                    border: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.blue),
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(20),bottomRight:Radius.circular(20),),),
                  ),
                ),
              ),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    primary: Colors.grey,
                    textStyle: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                  onPressed: () {},
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.add),
                      Text("Add"),
                    ],
                  ))
            ],
          ),
        ),
      ),
    );
  }
}

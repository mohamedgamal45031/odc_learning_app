import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Settings extends StatelessWidget {
  List<String> settings = [
    "FAQ",
    "Terms & Conditions",
    "Our Partners",
    "Support",
    "Log out"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: Text("Settings",
                style: GoogleFonts.poppins(
                    color: Colors.black,
                    fontSize: 25,
                    fontWeight: FontWeight.w600),),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: settings.length,
              itemBuilder: (context, index) => Container(
                height: 60,

                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("${settings[index]}",
                            style: GoogleFonts.poppins(
                                color: Colors.black,
                                fontSize: 18,
                                fontWeight: FontWeight.w500)),
                        IconButton(
                            onPressed: () {}, icon: Icon(Icons.arrow_forward_ios,color: Colors.grey,)),
                      ],
                    ),
                    if (index != settings.length - 1)
                      Expanded(
                        child: Divider(
                          height: 2,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
